---
title: Yun Test With hexo-tag-common
date: 2020-10-06 20:02:15
updated: 2020-10-06 20:02:15
type:
---

## [hexo-tag-common](https://github.com/YunYouJun/hexo-tag-common)

### Tabs

> See more information [here](https://theme-next.js.org/docs/tag-plugins/tabs.html).

{% tabs First unique name %}

<!-- tab -->

**This is Tab 1.**

<!-- endtab -->

<!-- tab -->

**This is Tab 2.**

<!-- endtab -->

<!-- tab -->

**This is Tab 3.**

<!-- endtab -->

{% endtabs %}

```md
{% tabs First unique name %}

<!-- tab -->

**This is Tab 1.**

<!-- endtab -->

<!-- tab -->

**This is Tab 2.**

<!-- endtab -->

<!-- tab -->

**This is Tab 3.**

<!-- endtab -->

{% endtabs %}
```
