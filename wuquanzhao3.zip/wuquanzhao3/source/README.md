# My Static Blog

[![GitHub Pages](https://github.com/YunYouJun/yunyoujun.github.io/workflows/GitHub%20Pages/badge.svg)](https://github.com/YunYouJun/yunyoujun.github.io/actions)

Welcome to My Blog!

This is built by [Hexo](https://hexo.io/) with [Yun](https://github.com/YunYouJun/hexo-theme-yun).
