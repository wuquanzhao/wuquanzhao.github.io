---
title: 相册集
date: 2020-04-18 16:27:24
updated: 2020-04-18 16:27:24
type: albums
albums:
  - caption: 夕阳西下
    url: /albums/sunset.html
    cover: https://interactive-examples.mdn.mozilla.net/media/examples/elephant-660-480.jpg
    desc: 我想起那天夕阳下的奔跑
  - caption: 青春
    url: /albums/young.html
    cover: https://picsum.photos/510/300?random
    desc: 那是我逝去的青春
  - caption: 日常
    url: /albums/daily.html
    cover: https://picsum.photos/800/300?random
    desc: #我们一日日度过的所谓日常
  - caption: 奇迹
    url: /albums/miracle.html
    cover: https://picsum.photos/600/200?random
    desc: 实际上可能是接连不断的奇迹
---
