---
title: 空调房
date: 2020-12-06 02:02:15
updated: 2020-12-06 17:46:15
reward: true
---

> 我们在此处安装了空调，您可以在此自由休憩。

---

<iframe height="740" frameborder="no" src="https://ac.yunyoujun.cn"></iframe>

---

裸机：<https://ac.yunyoujun.cn>
空调售后：[air-conditioner](https://github.com/YunYouJun/air-conditioner)
