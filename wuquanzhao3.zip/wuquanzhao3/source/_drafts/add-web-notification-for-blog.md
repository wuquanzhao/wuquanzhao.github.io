---
title: add-web-notification-for-blog
date: 2020-05-30 03:02:13
updated: 2020-05-30 03:02:13
tags:
categories:
---

<!-- more -->

---

To Be Continued.

<!-- Q.E.D. -->

我一开始是想使用 [webpushr](https://www.webpushr.com/)，但是建立好 Site 后不知为何总是显示 404。

![webpushr-404](https://upyun.yunyoujun.cn/images/webpushr-404.jpg)

于是转为使用了 [PushBots](https://app.pushbots.com/)。

所以并没有使用 [hexo-web-push-notification](https://github.com/glazec/hexo-web-push-notification) 这个插件。

[开放式平台](https://developer.mozilla.org/zh-CN/docs/Web/API/Push_API)

[使用 Web Notifications](https://developer.mozilla.org/zh-CN/docs/Web/API/notification/Using_Web_Notifications)
