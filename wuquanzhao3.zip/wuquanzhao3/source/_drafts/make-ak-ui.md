---
title: make-ak-ui
date: 2020-04-01 01:19:19
updated: 2020-04-01 01:19:19
tags:
categories:
---

<!-- more -->

说起来，我当初玩明日方舟的缘由，正是缘自从某处看了篇关于其 UI 分析的文章。
现在也终于算是回归本心。（~~不忘初心，牢记使命~~）

---

To Be Continued.

<!-- Q.E.D. -->
