---
title: 我的青春恋爱物语-完
date: 2021-03-09 01:52:41
updated: 2021-03-09 01:52:41
tags:
categories:
---

<!-- more -->

`eWFybiBnbG9iYWwgYWRkIGxsbQ==`

![奇怪的彩蛋](https://upyun.yunyoujun.cn/images/women-day-strange-egg.jpg)

> 既然知道总有一天会失去，既然任何关系都有结束的一天，那就该为了不要失去真正在乎的东西而努力。

---

To Be Continued.

<!-- Q.E.D. -->
